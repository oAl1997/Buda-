-- הריצו ב-Supabase: SQL Editor
create table docs(col text not null,id text not null,data jsonb not null default '{}',owner uuid,created timestamptz default now(),primary key(col,id));
alter table docs enable row level security;
create table admins(email text primary key);
insert into admins values('osherhasson997@gmail.com'); -- מייל המנהל (חייב להיות זהה למשתמש שתיצרו ב-Auth)
create function is_admin() returns boolean language sql stable security definer as $$select exists(select 1 from admins where email=(auth.jwt()->>'email'))$$;
create policy admin_all on docs for all using(is_admin()) with check(is_admin());
create policy pub_read on docs for select using(col in('published','comments','likes'));
create policy ins_pending on docs for insert to authenticated with check(col='pending' and length(data::text)<6000);
create policy ins_comment on docs for insert to authenticated with check(col='comments' and length(data::text)<1000);
create policy likes_ins on docs for insert to authenticated with check(col='likes' and owner=auth.uid());
create policy likes_upd on docs for update to authenticated using(col='likes' and owner=auth.uid());
create policy likes_del on docs for delete to authenticated using(col='likes' and owner=auth.uid());
create policy inbox_own on docs for all to authenticated using(col='inbox' and id=auth.uid()::text) with check(col='inbox' and id=auth.uid()::text);
alter publication supabase_realtime add table docs;
